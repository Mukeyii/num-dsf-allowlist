# License

Licensed under the Apache License, Version 2.0. See `LICENSE` for the full text.
